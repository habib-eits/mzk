
 <input type="text"  class="form-control" name="Voucher" id="Voucher" value="{{$d}}-{{$data[0]->VHNO}}" >
 
  

 




 
 