<input type="text"  class="form-control" name="InvoiceNo" id="InvoiceNo" value="{{$d}}-{{$data[0]->VHNO}}" >



 
 