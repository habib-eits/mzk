<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>{{$pagetitle}}</title>
    <style type="text/css">
<!--
.style1 {font-size: 20px}
body,td,th {
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
-->
    </style>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>
	
<div align="center">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td colspan="2"><div align="center" class="style1">{{$company[0]->Name}} </div></td>
    </tr>
    <tr>
      <td colspan="2"><div align="center"><strong>Stock Inventory </strong></div></td>
    </tr>
    <tr>
      <td width="50%"></td>
	  <td width="50%"><div align="right">DATED: {{date('d-m-Y')}}</div></td>
    
    </tr>
  </table>
    <?php 
            $SubTotal=0;
            $Tax=0;
            $GrandTotal=0;
             ?>
  <table width="100%" border="1" cellspacing="0" cellpadding="3" style="border-collapse:collapse;">
    <tr>
      <td width="5%" bgcolor="#CCCCCC"><div align="center"><strong>S#</strong></div></td>
      <td width="70%" bgcolor="#CCCCCC"><div align="left"><strong>ITEM NAME#</strong></div></td>
      <td width="10%" bgcolor="#CCCCCC"><div align="center"><strong>UNIT </strong></div></td>
      <td width="10%" bgcolor="#CCCCCC"><div align="center"><strong>QTY IN</strong></div></td>
      
      <td width="10%" bgcolor="#CCCCCC"><div align="center"><strong>QTY OUT</strong></div></td>
      <td width="10%" bgcolor="#CCCCCC"><div align="right"><strong>BALANCE</strong></div></td>
       
    </tr>
   @foreach ($inventory as $key => $value)
   	 

      
    
    <tr>
      <td><div align="center">{{$key+1}}</div></td>
      <td><div align="left">{{$value->ItemName}}</div></td>
      
      
       <td><div align="center">{{$value->UnitName}}</div></td>
       <td><div align="center">{{number_format($value->QtyIn,2)}}</div></td>
      <td><div align="center">{{number_format($value->QtyOut,2)}}</div></td>
      <td><div align="center">{{number_format($value->Balance,2)}}</div></td>
      
    </tr>
@endforeach
 
  </table>
  <p>&nbsp;</p>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th scope="col">&nbsp;</th>
      <th scope="col">&nbsp;</th>
    </tr>
    <tr>
      <th width="50%" scope="col">...................................................................</th>
      <th width="50%" scope="col">...................................................................</th>
    </tr>
    <tr>
      <td width="50%"><div align="center">Supervisor Name </div></td>
      <td width="50%"><div align="center">Date</div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
</body>
</html>